package karanganbungafx;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
public class Bunga {
    StringProperty namaBunga;

    public Bunga(String namaBunga) {
        this.namaBunga = new SimpleStringProperty(namaBunga);
    }

    public String getNamaBunga() {
        return namaBunga.get();
    }

    public void setNamaBunga(String namaBunga) {
        this.namaBunga.set(namaBunga);
    }

}
