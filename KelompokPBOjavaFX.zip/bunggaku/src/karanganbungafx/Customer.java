package karanganbungafx;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
public class Customer {
    IntegerProperty IDCustom;
    StringProperty PesanBunga;
    StringProperty tanggal;
    StringProperty ucapan;

    public Customer(Integer IDCustom, String PesanBunga, String tanggal, String ucapan) {
        this.IDCustom = new SimpleIntegerProperty(IDCustom);
        this.PesanBunga = new SimpleStringProperty(PesanBunga);
        this.tanggal = new SimpleStringProperty(tanggal);
        this.ucapan = new SimpleStringProperty(ucapan);
    }

    public Integer getIDCustom() {
        return IDCustom.get();
    }

    public void setIDCustom(Integer IDCustom) {
        this.IDCustom.set(IDCustom);
    }

    public String getPesanBunga() {
        return PesanBunga.get();
    }

    public void setPesanBunga(String PesanBunga) {
        this.PesanBunga.set(PesanBunga);
    }

    public String getTanggal() {
        return tanggal.get();
    }

    public void setTanggal(String tanggal) {
        this.tanggal.set(tanggal);
    }

    public String getUcapan() {
        return ucapan.get();
    }

    public void setUcapan(String ucapan) {
        this.ucapan.set(ucapan);
    }
    
    

}
