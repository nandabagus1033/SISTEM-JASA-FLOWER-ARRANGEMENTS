package karanganbungafx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import karanganbungafx.database.DBHelper;

public class BungaDataModel {
    public final Connection conn;
    
    public BungaDataModel(String driver) throws SQLException {
        this.conn = DBHelper.getConnection(driver);
    }
    
    public void addBAlami(BungaAlami alami) throws SQLException{
        String insertBunga = "INSERT INTO bunga (nama_bunga)"
                + "VALUES (?)";
        PreparedStatement stmtBunga = conn.prepareStatement(insertBunga);
        stmtBunga.setString(1,alami.getNamaBunga());
        stmtBunga.execute();
        
        String insertAlmi = "INSERT INTO bungan_alami (nama_bunga, hari)"
                + "VALUES (?,?)";
        PreparedStatement stmtAlami = conn.prepareStatement(insertAlmi);
        stmtAlami.setString(1,alami.getNamaBunga());
        stmtAlami.setInt(2,alami.getHari());
        stmtAlami.execute();
    }
    
    public void addBSintetis(BungaSintetis sintetis) throws SQLException{
        String insertBunga = "INSERT INTO bunga (nama_bunga)"
                + "VALUES (?)";
        PreparedStatement stmtBunga = conn.prepareStatement(insertBunga);
        stmtBunga.setString(1,sintetis.getNamaBunga());
        stmtBunga.execute();
        
        String insertSintetis = "INSERT INTO bunga_sintetis (nama_bunga, bahan)"
                + "VALUES (?,?)";
        PreparedStatement stmtAlami = conn.prepareStatement(insertSintetis);
        stmtAlami.setString(1,sintetis.getNamaBunga());
        stmtAlami.setString(2,sintetis.getBahan());
        stmtAlami.execute();
    }
    
    public void addCustomer(Customer cutom) throws SQLException{
        String insertBunga = "INSERT INTO customer (id_customer,bunga_pilihan,tanggal,ucapan)"
                + "VALUES (?,?,?,?)";
        PreparedStatement stmtBunga = conn.prepareStatement(insertBunga);
        stmtBunga.setInt(1,cutom.getIDCustom());
        stmtBunga.setString(2,cutom.getPesanBunga());
        stmtBunga.setString(3,cutom.getTanggal());
        stmtBunga.setString(4,cutom.getUcapan());
        stmtBunga.execute();
    }
    
    public int nextID() throws SQLException{
        String sql = "SELECT MAX(id_customer) from customer";
        ResultSet rs = conn.createStatement().executeQuery(sql);
        while (rs.next()){
                return rs.getInt(1)==0?10001:rs.getInt(1)+1;
                }
        return 10001;
    }
    
    public ObservableList<String> getNamaBunga(){
        ObservableList<String> data = FXCollections.observableArrayList();  
        String sql ="SELECT nama_bunga FROM bunga";
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                data.add(rs.getString(1));
                }
        } catch (SQLException ex) {
            Logger.getLogger(BungaDataModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }
    
    public ObservableList<BungaAlami> getDataAlami() throws SQLException{
        ObservableList<BungaAlami> data = FXCollections.observableArrayList();  
        String sql ="SELECT nama_bunga, hari FROM bungan_alami";
        
        ResultSet rs = conn.createStatement().executeQuery(sql);
        while(rs.next()){
            data.add(new BungaAlami(rs.getString(1),rs.getInt(2)));
        }
            
        return data;
    }
    public ObservableList<BungaSintetis> getDataSintetis() throws SQLException{
        ObservableList<BungaSintetis> data = FXCollections.observableArrayList();  
        String sql ="SELECT nama_bunga, bahan FROM bunga_sintetis";
        
        ResultSet rs = conn.createStatement().executeQuery(sql);
        while(rs.next()){
            data.add(new BungaSintetis(rs.getString(1),rs.getString(2)));
        }
            
        return data;
    }
    public ObservableList<Customer> getDataCustomer() throws SQLException{
        ObservableList<Customer> data = FXCollections.observableArrayList();  
        String sql ="SELECT id_customer, bunga_pilihan, tanggal, ucapan FROM customer";
        
        ResultSet rs = conn.createStatement().executeQuery(sql);
        while(rs.next()){
            data.add(new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4)));
        }
            
        return data;
    }

}
