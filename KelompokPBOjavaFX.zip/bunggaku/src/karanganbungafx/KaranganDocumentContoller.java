package karanganbungafx;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class KaranganDocumentContoller implements Initializable {
    
    public BungaDataModel BDM;
    
    @FXML
    private Label DBStatus;
    
    @FXML
    private TextField tf_bungaA;

    @FXML
    private Button btn_add1;

    @FXML
    private ComboBox<Integer> cb_hari;

    @FXML
    private Button btn_refresh1;

    @FXML
    private Button btn_clear1;

    @FXML
    private TableView<BungaAlami> tab_BAlami;

    @FXML
    private TableColumn<BungaAlami, String> c_NamaAlami;

    @FXML
    private TableColumn<BungaAlami, Integer> c_layu;

    @FXML
    private TextField tf_namaS;

    @FXML
    private Button btn_Add2;

    @FXML
    private ComboBox<String> cb_bahan;

    @FXML
    private Button btn_refresh2;

    @FXML
    private Button btn_clear2;

    @FXML
    private TableView<BungaSintetis> tab_BSintetis;

    @FXML
    private TableColumn<BungaSintetis, String> c_namaSintetis;

    @FXML
    private TableColumn<BungaSintetis, String> c_bahan;

    @FXML
    private TextField tf_ID;

    @FXML
    private Button btn_add3;

    @FXML
    private TextField tf_ucapan;

    @FXML
    private ComboBox<String> cb_pilihan;

    @FXML
    private DatePicker dt_tanggal;

    @FXML
    private Button btn_refresh3;

    @FXML
    private Button btn_clear3;

    @FXML
    private TableView<Customer> tab_Customer;

    @FXML
    private TableColumn<Customer, Integer> c_ID;

    @FXML
    private TableColumn<Customer, String> c_pilihan;

    @FXML
    private TableColumn<Customer, String> c_tanggal;

    @FXML
    private TableColumn<Customer, String> c_ucapan;

    @FXML
    void handleAdd1(ActionEvent event) {
        BungaAlami BA = new BungaAlami(tf_bungaA.getText(), cb_hari.getValue());        
        
        try {
            BDM.addBAlami(BA);
            btn_refresh1.fire();
            btn_clear1.fire();
            cb_pilihan.setItems(BDM.getNamaBunga());
        } catch (SQLException ex) {
            Logger.getLogger(KaranganDocumentContoller.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    void handleAdd2(ActionEvent event) {
        BungaSintetis BS = new BungaSintetis(tf_namaS.getText(), cb_bahan.getValue());        
        
        try {
            BDM.addBSintetis(BS);
            btn_refresh2.fire();
            btn_clear2.fire();
            cb_pilihan.setItems(BDM.getNamaBunga());
        } catch (SQLException ex) {
            Logger.getLogger(KaranganDocumentContoller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void handleAdd3(ActionEvent event) {
        Customer ct = new Customer(Integer.parseInt(tf_ID.getText()), cb_pilihan.getValue(), String.valueOf(dt_tanggal.getValue()), tf_ucapan.getText());        
        
        try {
            BDM.addCustomer(ct);
            btn_refresh3.fire();
            btn_clear3.fire();
            
        } catch (SQLException ex) {
            Logger.getLogger(KaranganDocumentContoller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void handleClear1(ActionEvent event) {
        tf_bungaA.setText(null);
    }

    @FXML
    void handleClear2(ActionEvent event) {
        tf_namaS.setText(null);
    }

    @FXML
    void handleClear3(ActionEvent event) throws SQLException {
        tf_ID.setText(String.valueOf(BDM.nextID()));
        tf_ucapan.setText(null);
    }   

    @FXML
    void handleRefresh1(ActionEvent event) throws SQLException {
        ObservableList<BungaAlami> data = BDM.getDataAlami();
        c_NamaAlami.setCellValueFactory(new PropertyValueFactory<>("namaBunga"));
        c_layu.setCellValueFactory(new PropertyValueFactory<>("hari"));
        tab_BAlami.setItems(data);
    }

    @FXML
    void handleRefresh2(ActionEvent event) throws SQLException {
        ObservableList<BungaSintetis> data = BDM.getDataSintetis();
        c_namaSintetis.setCellValueFactory(new PropertyValueFactory<>("namaBunga"));
        c_bahan.setCellValueFactory(new PropertyValueFactory<>("bahan"));
        tab_BSintetis.setItems(data);
    }

    @FXML
    void handleRefresh3(ActionEvent event) throws SQLException {
        ObservableList<Customer> data = BDM.getDataCustomer();
        c_ID.setCellValueFactory(new PropertyValueFactory<>("IDCustom"));
        c_pilihan.setCellValueFactory(new PropertyValueFactory<>("PesanBunga"));
        c_tanggal.setCellValueFactory(new PropertyValueFactory<>("tanggal"));
        c_ucapan.setCellValueFactory(new PropertyValueFactory<>("ucapan"));
        tab_Customer.setItems(data);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ObservableList<Integer> layu = FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9);
        ObservableList<String> bahan = FXCollections.observableArrayList("Kain","plastik","karet","kertas");
        cb_hari.setItems(layu);
        cb_bahan.setItems(bahan);
        
        try {
            BDM = new BungaDataModel("MYSQL");
            DBStatus.setText(BDM.conn==null?"Gagal Terhubung":"Terhubung");
            tf_ID.setText(String.valueOf(BDM.nextID()));
            cb_pilihan.setItems(BDM.getNamaBunga());
            btn_refresh1.fire();
            btn_refresh2.fire();
            btn_refresh3.fire();
        } catch (SQLException ex) {
            Logger.getLogger(KaranganDocumentContoller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
