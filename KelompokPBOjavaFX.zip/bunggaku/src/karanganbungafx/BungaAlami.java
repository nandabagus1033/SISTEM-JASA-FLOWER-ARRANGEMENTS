package karanganbungafx;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
public class BungaAlami extends Bunga{
    IntegerProperty hari;

    public BungaAlami(String namaBunga, int hari) {
        super(namaBunga);
        this.hari = new SimpleIntegerProperty(hari);
    }

    public Integer getHari() {
        return hari.get();
    }

    public void setHari(Integer hari) {
        this.hari.set(hari);
    }
    

}
