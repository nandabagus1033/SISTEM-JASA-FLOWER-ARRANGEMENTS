package karanganbungafx;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
public class BungaSintetis extends Bunga{
    StringProperty bahan;

    public BungaSintetis(String namaBunga, String bahan) {
        super(namaBunga);
        this.bahan = new SimpleStringProperty(bahan);
    }

    public String getBahan() {
        return bahan.get();
    }

    public void setBahan(String bahan) {
        this.bahan.set(bahan);
    }
    

}
